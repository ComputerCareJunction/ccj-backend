# ccj-backend

## Dashboard API setup

Admin routes verify Firebase ID tokens for the `ccj-web` project. An authenticated Firebase user must either have the Firebase custom claim `admin: true` or their email must be included in the Worker `ADMIN_EMAILS` comma-separated variable. Configure the allowlist in Cloudflare before using the admin dashboard; access is denied by default when neither is configured.

The dashboard's **Firebase Users** screen lists Firebase Authentication accounts. Configure Worker secrets `FIREBASE_CLIENT_EMAIL` and `FIREBASE_PRIVATE_KEY` from a service account in the `ccj-web` Google Cloud project and grant it Firebase Authentication user-management permissions needed to list, create, retrieve, and update accounts. Keep the private key only in Wrangler secrets. User provisioning runs through the Firebase Admin SDK in this Worker and writes application access records to D1 without storing passwords. A retry safely completes the D1 write if Firebase account creation succeeded but the database was temporarily unavailable. Application access is checked against both the signed Firebase ID token and an active D1 record for password and Google sign-in. Admin APIs additionally require the configured admin claim/email allowlist and an active D1 record.

The Users screen displays application access state and allows admins to grant or revoke it. Existing Firebase accounts without an application record are denied at sign-in until an admin grants access. Firebase accounts created by the admin form are registered in both systems. Employee assignment remains separate and links by Firebase UID.

After deploying code that adds a migration, apply it once to the remote D1 database:

```powershell
npm run d1:migrate:dashboard
npm run d1:migrate:firebase-employees
npm run d1:migrate:careers
npm run d1:migrate:application-users
npm run d1:migrate:section-permissions
npm run d1:migrate:tickets
npm run d1:migrate:assets
npm run d1:migrate:inventory
npm run deploy
```

The inventory migration converts the legacy Assets rows into purchase orders, purchase lines, sales, sale lines, and unique item records. It keeps the original rows in `assets_legacy` for reference. Apply it after `0008_assets.sql` and before deploying the inventory API. Existing GST percentages were not persisted by the old API; migrated line totals and other saved fields are retained, while migrated GST percentages default to zero.

The Assets API uses `/purchases`, `/sales`, `/items`, `/items/available`, and `/stock`. Purchase and sale documents are saved atomically in D1; database triggers maintain `items.current_stock`, reject sales that exceed stock, and adjust stock when documents change status or are edited/deleted. Inventory write access follows the existing Assets section permissions.

The ticket migration assigns existing support tickets sequential `CCJ-01` style numbers and initializes the ticket number sequence. Apply it before deploying the Worker code that creates tickets with sequential numbers.

Section permissions are stored on each application user as read/write grants for Products, Orders, Tickets, Users, Employees, Leads, and Resources. Write grants include read access. Admins always have full access; standard users receive no section grants until an admin configures them in the Users screen.

The migration is additive and creates the user, employee, and attendance tables while adding the dashboard fields used by existing products, contacts, tickets, and orders.

The careers migration creates the openings table and seeds the existing roles. Admins can manage openings under **Resources → Careers**; active openings are read by the public Careers page.