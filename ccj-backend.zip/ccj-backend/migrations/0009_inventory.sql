PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    unit TEXT NOT NULL DEFAULT 'unit',
    category TEXT,
    current_stock INTEGER NOT NULL DEFAULT 0 CHECK (current_stock >= 0),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    id TEXT PRIMARY KEY,
    bill_no TEXT NOT NULL COLLATE NOCASE UNIQUE,
    supplier TEXT NOT NULL,
    date TEXT NOT NULL,
    total_amount REAL NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    status TEXT NOT NULL DEFAULT 'Completed',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchase_items (
    id TEXT PRIMARY KEY,
    purchase_order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES items(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    gst_percentage REAL NOT NULL DEFAULT 0 CHECK (gst_percentage >= 0),
    amount REAL NOT NULL CHECK (amount >= 0),
    notes TEXT,
    category TEXT
);

CREATE TABLE IF NOT EXISTS sales (
    id TEXT PRIMARY KEY,
    bill_no TEXT NOT NULL COLLATE NOCASE UNIQUE,
    date TEXT NOT NULL,
    customer TEXT NOT NULL,
    total_amount REAL NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    status TEXT NOT NULL DEFAULT 'Completed',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sale_items (
    id TEXT PRIMARY KEY,
    sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES items(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    gst_percentage REAL NOT NULL DEFAULT 0 CHECK (gst_percentage >= 0),
    amount REAL NOT NULL CHECK (amount >= 0),
    notes TEXT,
    category TEXT
);

CREATE INDEX IF NOT EXISTS idx_purchase_orders_date ON purchase_orders(date);
CREATE INDEX IF NOT EXISTS idx_purchase_items_order ON purchase_items(purchase_order_id);
CREATE INDEX IF NOT EXISTS idx_purchase_items_item ON purchase_items(item_id);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(date);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
CREATE INDEX IF NOT EXISTS idx_sale_items_item ON sale_items(item_id);

INSERT INTO items (id, name, unit, category)
SELECT
    'legacy-item-' || lower(hex(randomblob(16))),
    MIN(trim(item)),
    'unit',
    MIN(NULLIF(trim(category), ''))
FROM assets
WHERE trim(item) <> ''
GROUP BY lower(trim(item));

INSERT INTO purchase_orders (id, bill_no, supplier, date, total_amount, status)
SELECT
    'legacy-purchase-' || lower(hex(randomblob(16))),
    COALESCE(NULLIF(trim(bill_no), ''), 'LEGACY-PUR-' || id),
    MIN(vendor),
    MIN(date),
    SUM(total_amount),
    MIN(COALESCE(NULLIF(status, ''), 'Completed'))
FROM assets
WHERE movement = 'Purchase'
GROUP BY COALESCE(NULLIF(trim(bill_no), ''), 'LEGACY-PUR-' || id) COLLATE NOCASE;

INSERT INTO purchase_items (id, purchase_order_id, item_id, quantity, unit_price, amount, notes, category)
SELECT
    'legacy-purchase-item-' || a.id,
    po.id,
    i.id,
    a.qty,
    a.unit_amount,
    a.total_amount,
    a.notes,
    a.category
FROM assets a
JOIN purchase_orders po
    ON po.bill_no = COALESCE(NULLIF(trim(a.bill_no), ''), 'LEGACY-PUR-' || a.id) COLLATE NOCASE
JOIN items i
    ON i.name = trim(a.item) COLLATE NOCASE
WHERE a.movement = 'Purchase';

INSERT INTO sales (id, bill_no, date, customer, total_amount, status)
SELECT
    'legacy-sale-' || lower(hex(randomblob(16))),
    COALESCE(NULLIF(trim(bill_no), ''), 'LEGACY-SAL-' || id),
    MIN(date),
    MIN(vendor),
    SUM(total_amount),
    MIN(COALESCE(NULLIF(status, ''), 'Completed'))
FROM assets
WHERE movement = 'Sales'
GROUP BY COALESCE(NULLIF(trim(bill_no), ''), 'LEGACY-SAL-' || id) COLLATE NOCASE;

INSERT INTO sale_items (id, sale_id, item_id, quantity, unit_price, amount, notes, category)
SELECT
    'legacy-sale-item-' || a.id,
    s.id,
    i.id,
    a.qty,
    a.unit_amount,
    a.total_amount,
    a.notes,
    a.category
FROM assets a
JOIN sales s
    ON s.bill_no = COALESCE(NULLIF(trim(a.bill_no), ''), 'LEGACY-SAL-' || a.id) COLLATE NOCASE
JOIN items i
    ON i.name = trim(a.item) COLLATE NOCASE
WHERE a.movement = 'Sales';

UPDATE items
SET current_stock =
    MAX(0,
        COALESCE((
            SELECT SUM(pi.quantity)
            FROM purchase_items pi
            JOIN purchase_orders po ON po.id = pi.purchase_order_id
            WHERE pi.item_id = items.id AND po.status <> 'Cancelled'
        ), 0) -
        COALESCE((
            SELECT SUM(si.quantity)
            FROM sale_items si
            JOIN sales s ON s.id = si.sale_id
            WHERE si.item_id = items.id AND s.status <> 'Cancelled'
        ), 0)
    );

CREATE TRIGGER IF NOT EXISTS purchase_items_stock_insert
AFTER INSERT ON purchase_items
WHEN (SELECT status FROM purchase_orders WHERE id = NEW.purchase_order_id) <> 'Cancelled'
BEGIN
    UPDATE items SET current_stock = current_stock + NEW.quantity WHERE id = NEW.item_id;
END;

CREATE TRIGGER IF NOT EXISTS purchase_items_stock_delete
AFTER DELETE ON purchase_items
WHEN (SELECT status FROM purchase_orders WHERE id = OLD.purchase_order_id) <> 'Cancelled'
BEGIN
    UPDATE items SET current_stock = current_stock - OLD.quantity WHERE id = OLD.item_id;
END;

CREATE TRIGGER IF NOT EXISTS purchase_items_stock_update
AFTER UPDATE OF item_id, quantity ON purchase_items
BEGIN
    UPDATE items
    SET current_stock = current_stock
        - CASE WHEN (SELECT status FROM purchase_orders WHERE id = OLD.purchase_order_id) <> 'Cancelled' THEN OLD.quantity ELSE 0 END
        + CASE WHEN (SELECT status FROM purchase_orders WHERE id = NEW.purchase_order_id) <> 'Cancelled' THEN NEW.quantity ELSE 0 END
    WHERE id = OLD.item_id AND OLD.item_id = NEW.item_id;
    UPDATE items
    SET current_stock = current_stock - OLD.quantity
    WHERE id = OLD.item_id AND OLD.item_id <> NEW.item_id
        AND (SELECT status FROM purchase_orders WHERE id = OLD.purchase_order_id) <> 'Cancelled';
    UPDATE items
    SET current_stock = current_stock + NEW.quantity
    WHERE id = NEW.item_id AND OLD.item_id <> NEW.item_id
        AND (SELECT status FROM purchase_orders WHERE id = NEW.purchase_order_id) <> 'Cancelled';
END;

CREATE TRIGGER IF NOT EXISTS purchase_orders_stock_status
AFTER UPDATE OF status ON purchase_orders
WHEN OLD.status <> NEW.status
BEGIN
    UPDATE items
    SET current_stock = current_stock + CASE
        WHEN OLD.status = 'Cancelled' AND NEW.status <> 'Cancelled' THEN (
            SELECT COALESCE(SUM(quantity), 0) FROM purchase_items
            WHERE purchase_order_id = NEW.id AND item_id = items.id
        )
        WHEN OLD.status <> 'Cancelled' AND NEW.status = 'Cancelled' THEN -(
            SELECT COALESCE(SUM(quantity), 0) FROM purchase_items
            WHERE purchase_order_id = NEW.id AND item_id = items.id
        )
        ELSE 0
    END
    WHERE id IN (SELECT item_id FROM purchase_items WHERE purchase_order_id = NEW.id);
END;

CREATE TRIGGER IF NOT EXISTS sale_items_stock_check
BEFORE INSERT ON sale_items
WHEN (SELECT status FROM sales WHERE id = NEW.sale_id) <> 'Cancelled'
    AND COALESCE((SELECT current_stock FROM items WHERE id = NEW.item_id), 0) < NEW.quantity
BEGIN
    SELECT RAISE(ABORT, 'Insufficient stock for sale');
END;

CREATE TRIGGER IF NOT EXISTS sale_items_stock_insert
AFTER INSERT ON sale_items
WHEN (SELECT status FROM sales WHERE id = NEW.sale_id) <> 'Cancelled'
BEGIN
    UPDATE items SET current_stock = current_stock - NEW.quantity WHERE id = NEW.item_id;
END;

CREATE TRIGGER IF NOT EXISTS sale_items_stock_delete
AFTER DELETE ON sale_items
WHEN (SELECT status FROM sales WHERE id = OLD.sale_id) <> 'Cancelled'
BEGIN
    UPDATE items SET current_stock = current_stock + OLD.quantity WHERE id = OLD.item_id;
END;

CREATE TRIGGER IF NOT EXISTS sale_items_stock_check_update
BEFORE UPDATE OF item_id, quantity ON sale_items
WHEN (SELECT status FROM sales WHERE id = NEW.sale_id) <> 'Cancelled'
    AND COALESCE((
        SELECT current_stock + CASE
            WHEN OLD.item_id = NEW.item_id AND (SELECT status FROM sales WHERE id = OLD.sale_id) <> 'Cancelled'
            THEN OLD.quantity ELSE 0
        END
        FROM items WHERE id = NEW.item_id
    ), 0) < NEW.quantity
BEGIN
    SELECT RAISE(ABORT, 'Insufficient stock for sale');
END;

CREATE TRIGGER IF NOT EXISTS sale_items_stock_update
AFTER UPDATE OF item_id, quantity ON sale_items
BEGIN
    UPDATE items
    SET current_stock = current_stock
        + CASE WHEN (SELECT status FROM sales WHERE id = OLD.sale_id) <> 'Cancelled' THEN OLD.quantity ELSE 0 END
        - CASE WHEN (SELECT status FROM sales WHERE id = NEW.sale_id) <> 'Cancelled' THEN NEW.quantity ELSE 0 END
    WHERE id = OLD.item_id AND OLD.item_id = NEW.item_id;
    UPDATE items
    SET current_stock = current_stock + OLD.quantity
    WHERE id = OLD.item_id AND OLD.item_id <> NEW.item_id
        AND (SELECT status FROM sales WHERE id = OLD.sale_id) <> 'Cancelled';
    UPDATE items
    SET current_stock = current_stock - NEW.quantity
    WHERE id = NEW.item_id AND OLD.item_id <> NEW.item_id
        AND (SELECT status FROM sales WHERE id = NEW.sale_id) <> 'Cancelled';
END;

CREATE TRIGGER IF NOT EXISTS sales_stock_status
AFTER UPDATE OF status ON sales
WHEN OLD.status <> NEW.status
BEGIN
    UPDATE items
    SET current_stock = current_stock + CASE
        WHEN OLD.status = 'Cancelled' AND NEW.status <> 'Cancelled' THEN -(
            SELECT COALESCE(SUM(quantity), 0) FROM sale_items
            WHERE sale_id = NEW.id AND item_id = items.id
        )
        WHEN OLD.status <> 'Cancelled' AND NEW.status = 'Cancelled' THEN (
            SELECT COALESCE(SUM(quantity), 0) FROM sale_items
            WHERE sale_id = NEW.id AND item_id = items.id
        )
        ELSE 0
    END
    WHERE id IN (SELECT item_id FROM sale_items WHERE sale_id = NEW.id);
END;

ALTER TABLE assets RENAME TO assets_legacy;
