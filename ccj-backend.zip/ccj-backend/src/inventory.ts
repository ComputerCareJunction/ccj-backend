type D1Database = {
    prepare(query: string): D1PreparedStatement;
    batch<T = unknown>(statements: D1PreparedStatement[]): Promise<Array<{ results?: T[]; meta?: { changes?: number } }>>;
};

type D1PreparedStatement = {
    bind(...values: unknown[]): D1PreparedStatement;
    all<T = Record<string, unknown>>(): Promise<{ results?: T[] }>;
    first<T = Record<string, unknown>>(): Promise<T | null>;
    run(): Promise<{ meta?: { changes?: number } }>;
};

type InventoryEnv = { DB: D1Database };
type DocumentStatus = 'Completed' | 'Pending' | 'Received' | 'Dispatched' | 'Cancelled';
type DocumentType = 'purchase' | 'sale';

type PurchaseLineInput = {
    id?: string;
    name: string;
    unit?: string;
    category?: string;
    quantity: number;
    unit_price: number;
    gst_percentage?: number;
    notes?: string | null;
};

type SaleLineInput = {
    id?: string;
    item_id: string;
    quantity: number;
    unit_price: number;
    gst_percentage?: number;
    notes?: string | null;
};

type DocumentInput = {
    bill_no: string;
    date: string;
    party: string;
    status: DocumentStatus;
    items: Array<PurchaseLineInput | SaleLineInput>;
};

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
};

const json = (data: unknown, status = 200): Response =>
    new Response(JSON.stringify(data), { status, headers: corsHeaders });

const errorResponse = (message: string, status: number): Response =>
    json({ error: message }, status);

const isRecord = (value: unknown): value is Record<string, unknown> =>
    Boolean(value) && typeof value === 'object' && !Array.isArray(value);

const newId = (prefix: string) => `${prefix}_${crypto.randomUUID()}`;
const roundMoney = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

const lineAmount = (quantity: number, unitPrice: number, gstPercentage: number) => {
    const subtotal = roundMoney(quantity * unitPrice);
    return roundMoney(subtotal + roundMoney(subtotal * gstPercentage / 100));
};

const statusIsValid = (value: unknown): value is DocumentStatus =>
    value === 'Completed' || value === 'Pending' || value === 'Received' || value === 'Dispatched' || value === 'Cancelled';

const parseDocument = (body: unknown, type: DocumentType): DocumentInput | string => {
    if (!isRecord(body)) return 'A JSON object is required.';
    const billNo = typeof body.bill_no === 'string' ? body.bill_no.trim() : '';
    const date = typeof body.date === 'string' ? body.date.trim() : '';
    const partyKey = type === 'purchase' ? 'supplier' : 'customer';
    const rawParty = body[partyKey];
    const party = typeof rawParty === 'string' ? rawParty.trim() : '';
    const status = body.status === undefined ? 'Completed' : body.status;
    const parsedDate = new Date(`${date}T00:00:00.000Z`);

    if (!billNo || billNo.length > 120) return 'A bill number of 1 to 120 characters is required.';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== date) return 'A valid date in YYYY-MM-DD format is required.';
    if (!party || party.length > 200) return `A ${partyKey} name of 1 to 200 characters is required.`;
    if (!statusIsValid(status)) return 'Invalid document status.';
    if (!Array.isArray(body.items) || body.items.length === 0 || body.items.length > 100) return 'Provide between 1 and 100 item lines.';

    const items: Array<PurchaseLineInput | SaleLineInput> = [];
    for (const rawLine of body.items) {
        if (!isRecord(rawLine)) return 'Each item line must be an object.';
        if (!['number', 'string'].includes(typeof rawLine.quantity) || String(rawLine.quantity).trim() === '') return 'Each quantity must be a positive whole number.';
        if (!['number', 'string'].includes(typeof rawLine.unit_price) || String(rawLine.unit_price).trim() === '') return 'Each unit price must be greater than zero.';
        if (rawLine.gst_percentage !== undefined && (!['number', 'string'].includes(typeof rawLine.gst_percentage) || String(rawLine.gst_percentage).trim() === '')) return 'GST percentage must be a non-negative number.';
        const quantity = Number(rawLine.quantity);
        const unitPrice = Number(rawLine.unit_price);
        const gstPercentage = rawLine.gst_percentage === undefined ? 0 : Number(rawLine.gst_percentage);
        if (!Number.isInteger(quantity) || quantity <= 0) return 'Each quantity must be a positive whole number.';
        if (!Number.isFinite(unitPrice) || unitPrice <= 0) return 'Each unit price must be greater than zero.';
        if (!Number.isFinite(gstPercentage) || gstPercentage < 0) return 'GST percentage must be a non-negative number.';
        if (rawLine.id !== undefined && (typeof rawLine.id !== 'string' || !rawLine.id)) return 'Invalid item line id.';

        if (rawLine.notes !== undefined && rawLine.notes !== null && typeof rawLine.notes !== 'string') return 'Item notes must be text.';
        const notes = rawLine.notes as string | null | undefined;
        if (type === 'purchase') {
            const name = typeof rawLine.name === 'string' ? rawLine.name.trim() : '';
            if (!name || name.length > 200) return 'Each purchase line requires an item name of 1 to 200 characters.';
            if (rawLine.unit !== undefined && typeof rawLine.unit !== 'string') return 'Item unit must be text.';
            if (rawLine.category !== undefined && typeof rawLine.category !== 'string') return 'Item category must be text.';
            const unit = rawLine.unit === undefined ? 'unit' : rawLine.unit.trim();
            const category = rawLine.category === undefined ? null : rawLine.category.trim() || null;
            items.push({
                ...(rawLine.id ? { id: rawLine.id as string } : {}),
                name,
                unit: unit || 'unit',
                category: category || undefined,
                quantity,
                unit_price: unitPrice,
                gst_percentage: gstPercentage,
                notes,
            });
        } else {
            if (typeof rawLine.item_id !== 'string' || !rawLine.item_id) return 'Each sale line requires an item_id selected from available stock.';
            if ('name' in rawLine || 'item' in rawLine) return 'Sales accept item_id only; item names cannot be submitted.';
            items.push({
                ...(rawLine.id ? { id: rawLine.id as string } : {}),
                item_id: rawLine.item_id,
                quantity,
                unit_price: unitPrice,
                gst_percentage: gstPercentage,
                notes,
            });
        }
    }

    const lineIds = items.flatMap((item) => item.id ? [item.id] : []);
    if (new Set(lineIds).size !== lineIds.length) return 'An item line cannot be submitted more than once.';

    return { bill_no: billNo, date, party, status, items };
};

const totalAmount = (items: DocumentInput['items']) =>
    roundMoney(items.reduce((total, item) => total + lineAmount(item.quantity, item.unit_price, item.gst_percentage || 0), 0));

const mapLine = (row: Record<string, unknown>) => ({
    id: row.id,
    item_id: row.item_id,
    name: row.name,
    unit: row.unit,
    category: row.category,
    quantity: Number(row.quantity),
    unit_price: Number(row.unit_price),
    gst_percentage: Number(row.gst_percentage || 0),
    amount: Number(row.amount),
    notes: row.notes,
});

export class InventoryController {
    static async handle(request: Request, env: InventoryEnv, url: URL): Promise<Response> {
        const path = url.pathname.replace(/^\/api/, '').replace(/\/+$/, '') || '/';
        const method = request.method;

        if (path === '/stock' && method === 'GET') return this.getStock(env);
        if (path === '/items/available' && method === 'GET') return this.getItems(env, true);
        if (path === '/items' && method === 'GET') return this.getItems(env, false, url.searchParams.get('search') || '');
        if (path === '/purchases' && method === 'GET') return this.listDocuments(env, 'purchase');
        if (path === '/purchases' && method === 'POST') return this.createDocument(request, env, 'purchase');
        if (path.startsWith('/purchases/')) return this.documentById(request, env, 'purchase', path.slice('/purchases/'.length));
        if (path === '/sales' && method === 'GET') return this.listDocuments(env, 'sale');
        if (path === '/sales' && method === 'POST') return this.createDocument(request, env, 'sale');
        if (path.startsWith('/sales/')) return this.documentById(request, env, 'sale', path.slice('/sales/'.length));

        return errorResponse('Inventory API endpoint not found.', 404);
    }

    private static async getItems(env: InventoryEnv, availableOnly: boolean, search = ''): Promise<Response> {
        const where = availableOnly ? 'WHERE current_stock > 0' : (search.trim() ? 'WHERE name LIKE ?' : '');
        const statement = env.DB.prepare(`
            SELECT id, name, unit, category, current_stock
            FROM items ${where}
            ORDER BY name COLLATE NOCASE
        `);
        const result = search.trim() && !availableOnly
            ? await statement.bind(`%${search.trim()}%`).all()
            : await statement.all();
        return json(result.results || []);
    }

    private static async getStock(env: InventoryEnv): Promise<Response> {
        const result = await env.DB.prepare(`
            SELECT
                i.id,
                i.name,
                i.unit,
                i.category,
                i.current_stock AS available_stock,
                COALESCE((
                    SELECT SUM(pi.quantity)
                    FROM purchase_items pi
                    JOIN purchase_orders po ON po.id = pi.purchase_order_id
                    WHERE pi.item_id = i.id AND po.status <> 'Cancelled'
                ), 0) AS total_purchased_qty,
                COALESCE((
                    SELECT SUM(si.quantity)
                    FROM sale_items si
                    JOIN sales s ON s.id = si.sale_id
                    WHERE si.item_id = i.id AND s.status <> 'Cancelled'
                ), 0) AS total_sold_qty,
                (
                    SELECT pi.unit_price
                    FROM purchase_items pi
                    JOIN purchase_orders po ON po.id = pi.purchase_order_id
                    WHERE pi.item_id = i.id AND po.status <> 'Cancelled'
                    ORDER BY po.date DESC, po.created_at DESC, po.rowid DESC, pi.rowid DESC
                    LIMIT 1
                ) AS last_unit_amount
            FROM items i
            ORDER BY i.name COLLATE NOCASE
        `).all();
        return json(result.results || []);
    }

    private static async listDocuments(env: InventoryEnv, type: DocumentType): Promise<Response> {
        const table = type === 'purchase' ? 'purchase_orders' : 'sales';
        const lineTable = type === 'purchase' ? 'purchase_items' : 'sale_items';
        const foreignKey = type === 'purchase' ? 'purchase_order_id' : 'sale_id';
        const partyColumn = type === 'purchase' ? 'supplier' : 'customer';
        const result = await env.DB.prepare(`
            SELECT h.*, h.${partyColumn} AS party, li.id AS line_id, li.item_id, li.quantity, li.unit_price,
                li.gst_percentage, li.amount, li.notes, i.name, i.unit,
                COALESCE(li.category, i.category) AS category
            FROM ${table} h
            LEFT JOIN ${lineTable} li ON li.${foreignKey} = h.id
            LEFT JOIN items i ON i.id = li.item_id
            ORDER BY h.date DESC, h.created_at DESC, li.rowid
        `).all<Record<string, unknown>>();
        const documents = new Map<string, Record<string, unknown> & { items: ReturnType<typeof mapLine>[] }>();
        for (const row of result.results || []) {
            const id = String(row.id);
            let document = documents.get(id);
            if (!document) {
                document = {
                    id,
                    bill_no: row.bill_no,
                    date: row.date,
                    [partyColumn]: row.party,
                    total_amount: Number(row.total_amount),
                    status: row.status,
                    created_at: row.created_at,
                    updated_at: row.updated_at,
                    items: [],
                };
                documents.set(id, document);
            }
            if (row.line_id) {
                document.items.push(mapLine({
                    id: row.line_id,
                    item_id: row.item_id,
                    name: row.name,
                    unit: row.unit,
                    category: row.category,
                    quantity: row.quantity,
                    unit_price: row.unit_price,
                    gst_percentage: row.gst_percentage,
                    amount: row.amount,
                    notes: row.notes,
                }));
            }
        }
        return json(Array.from(documents.values()));
    }

    private static async getDocument(env: InventoryEnv, type: DocumentType, id: string): Promise<Record<string, unknown> | null> {
        const headerTable = type === 'purchase' ? 'purchase_orders' : 'sales';
        const lineTable = type === 'purchase' ? 'purchase_items' : 'sale_items';
        const foreignKey = type === 'purchase' ? 'purchase_order_id' : 'sale_id';
        const partyColumn = type === 'purchase' ? 'supplier' : 'customer';
        const header = await env.DB.prepare(`SELECT * FROM ${headerTable} WHERE id = ?`).bind(id).first<Record<string, unknown>>();
        if (!header) return null;
        const lines = await env.DB.prepare(`
            SELECT li.id, li.item_id, li.quantity, li.unit_price, li.gst_percentage, li.amount, li.notes,
                i.name, i.unit, COALESCE(li.category, i.category) AS category
            FROM ${lineTable} li
            JOIN items i ON i.id = li.item_id
            WHERE li.${foreignKey} = ?
            ORDER BY li.rowid
        `).bind(id).all<Record<string, unknown>>();

        return {
            id: header.id,
            bill_no: header.bill_no,
            date: header.date,
            [partyColumn]: header[partyColumn],
            total_amount: Number(header.total_amount),
            status: header.status,
            created_at: header.created_at,
            updated_at: header.updated_at,
            items: (lines.results || []).map(mapLine),
        };
    }

    private static async createDocument(request: Request, env: InventoryEnv, type: DocumentType): Promise<Response> {
        const parsed = parseDocument(await request.json().catch(() => null), type);
        if (typeof parsed === 'string') return errorResponse(parsed, 400);
        const id = newId(type === 'purchase' ? 'pur' : 'sal');
        const total = totalAmount(parsed.items);

        try {
            const statements: D1PreparedStatement[] = [
                type === 'purchase'
                    ? env.DB.prepare('INSERT INTO purchase_orders (id, bill_no, supplier, date, total_amount, status) VALUES (?, ?, ?, ?, ?, ?)')
                        .bind(id, parsed.bill_no, parsed.party, parsed.date, total, parsed.status)
                    : env.DB.prepare('INSERT INTO sales (id, bill_no, customer, date, total_amount, status) VALUES (?, ?, ?, ?, ?, ?)')
                        .bind(id, parsed.bill_no, parsed.party, parsed.date, total, parsed.status),
            ];
            for (const line of parsed.items) {
                if (type === 'purchase') {
                    const purchaseLine = line as PurchaseLineInput;
                    statements.push(env.DB.prepare(`
                        INSERT INTO items (id, name, unit, category)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(name) DO NOTHING
                    `).bind(newId('itm'), purchaseLine.name, purchaseLine.unit || 'unit', purchaseLine.category || null));
                    statements.push(env.DB.prepare(`
                        INSERT INTO purchase_items (id, purchase_order_id, item_id, quantity, unit_price, gst_percentage, amount, notes, category)
                        VALUES (?, ?, (SELECT id FROM items WHERE name = ? COLLATE NOCASE), ?, ?, ?, ?, ?, ?)
                    `).bind(
                        newId('pil'),
                        id,
                        purchaseLine.name,
                        purchaseLine.quantity,
                        purchaseLine.unit_price,
                        purchaseLine.gst_percentage || 0,
                        lineAmount(purchaseLine.quantity, purchaseLine.unit_price, purchaseLine.gst_percentage || 0),
                        purchaseLine.notes || null,
                        purchaseLine.category || null,
                    ));
                } else {
                    const saleLine = line as SaleLineInput;
                    statements.push(env.DB.prepare(`
                        INSERT INTO sale_items (id, sale_id, item_id, quantity, unit_price, gst_percentage, amount, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    `).bind(
                        newId('sil'),
                        id,
                        saleLine.item_id,
                        saleLine.quantity,
                        saleLine.unit_price,
                        saleLine.gst_percentage || 0,
                        lineAmount(saleLine.quantity, saleLine.unit_price, saleLine.gst_percentage || 0),
                        saleLine.notes || null,
                    ));
                }
            }
            await env.DB.batch(statements);
        } catch (error) {
            return this.writeError(error, type);
        }

        const document = await this.getDocument(env, type, id);
        return json(document, 201);
    }

    private static async documentById(request: Request, env: InventoryEnv, type: DocumentType, rawId: string): Promise<Response> {
        const id = decodeURIComponent(rawId);
        if (request.method === 'GET') {
            const document = await this.getDocument(env, type, id);
            return document ? json(document) : errorResponse(`${type === 'purchase' ? 'Purchase order' : 'Sale'} not found.`, 404);
        }
        if (request.method === 'PUT') return this.updateDocument(request, env, type, id);
        if (request.method === 'DELETE') return this.deleteDocument(env, type, id);
        return errorResponse('Method not allowed.', 405);
    }

    private static async updateDocument(request: Request, env: InventoryEnv, type: DocumentType, id: string): Promise<Response> {
        const parsed = parseDocument(await request.json().catch(() => null), type);
        if (typeof parsed === 'string') return errorResponse(parsed, 400);
        const headerTable = type === 'purchase' ? 'purchase_orders' : 'sales';
        const lineTable = type === 'purchase' ? 'purchase_items' : 'sale_items';
        const foreignKey = type === 'purchase' ? 'purchase_order_id' : 'sale_id';
        const partyColumn = type === 'purchase' ? 'supplier' : 'customer';
        const current = await this.getDocument(env, type, id);
        if (!current) return errorResponse(`${type === 'purchase' ? 'Purchase order' : 'Sale'} not found.`, 404);

        const oldLinesResult = await env.DB.prepare(`SELECT id FROM ${lineTable} WHERE ${foreignKey} = ?`).bind(id).all<{ id: string }>();
        const oldIds = new Set((oldLinesResult.results || []).map((line) => line.id));
        const submittedIds = new Set(parsed.items.flatMap((line) => line.id ? [line.id] : []));
        for (const submittedId of submittedIds) {
            if (!oldIds.has(submittedId)) return errorResponse('An item line does not belong to this document.', 400);
        }
        const total = totalAmount(parsed.items);
        const statements: D1PreparedStatement[] = [
            type === 'purchase'
                ? env.DB.prepare(`UPDATE ${headerTable} SET bill_no = ?, supplier = ?, date = ?, total_amount = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
                    .bind(parsed.bill_no, parsed.party, parsed.date, total, parsed.status, id)
                : env.DB.prepare(`UPDATE ${headerTable} SET bill_no = ?, customer = ?, date = ?, total_amount = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
                    .bind(parsed.bill_no, parsed.party, parsed.date, total, parsed.status, id),
        ];

        for (const oldId of oldIds) {
            if (!submittedIds.has(oldId)) {
                statements.push(env.DB.prepare(`DELETE FROM ${lineTable} WHERE id = ? AND ${foreignKey} = ?`).bind(oldId, id));
            }
        }

        for (const line of parsed.items) {
            const lineId = line.id || newId(type === 'purchase' ? 'pil' : 'sil');
            if (type === 'purchase') {
                const purchaseLine = line as PurchaseLineInput;
                statements.push(env.DB.prepare(`
                    INSERT INTO items (id, name, unit, category)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(name) DO NOTHING
                `).bind(newId('itm'), purchaseLine.name, purchaseLine.unit || 'unit', purchaseLine.category || null));
                if (line.id) {
                    statements.push(env.DB.prepare(`
                        UPDATE purchase_items SET item_id = (SELECT id FROM items WHERE name = ? COLLATE NOCASE),
                            quantity = ?, unit_price = ?, gst_percentage = ?, amount = ?, notes = ?, category = ?
                        WHERE id = ? AND purchase_order_id = ?
                    `).bind(
                        purchaseLine.name,
                        purchaseLine.quantity,
                        purchaseLine.unit_price,
                        purchaseLine.gst_percentage || 0,
                        lineAmount(purchaseLine.quantity, purchaseLine.unit_price, purchaseLine.gst_percentage || 0),
                        purchaseLine.notes || null,
                        purchaseLine.category || null,
                        lineId,
                        id,
                    ));
                } else {
                    statements.push(env.DB.prepare(`
                        INSERT INTO purchase_items (id, purchase_order_id, item_id, quantity, unit_price, gst_percentage, amount, notes, category)
                        VALUES (?, ?, (SELECT id FROM items WHERE name = ? COLLATE NOCASE), ?, ?, ?, ?, ?, ?)
                    `).bind(
                        lineId,
                        id,
                        purchaseLine.name,
                        purchaseLine.quantity,
                        purchaseLine.unit_price,
                        purchaseLine.gst_percentage || 0,
                        lineAmount(purchaseLine.quantity, purchaseLine.unit_price, purchaseLine.gst_percentage || 0),
                        purchaseLine.notes || null,
                        purchaseLine.category || null,
                    ));
                }
            } else {
                const saleLine = line as SaleLineInput;
                const values = [
                    saleLine.item_id,
                    saleLine.quantity,
                    saleLine.unit_price,
                    saleLine.gst_percentage || 0,
                    lineAmount(saleLine.quantity, saleLine.unit_price, saleLine.gst_percentage || 0),
                    saleLine.notes || null,
                ];
                if (line.id) {
                    statements.push(env.DB.prepare(`
                        UPDATE sale_items SET item_id = ?, quantity = ?, unit_price = ?, gst_percentage = ?, amount = ?, notes = ?
                        WHERE id = ? AND sale_id = ?
                    `).bind(...values, lineId, id));
                } else {
                    statements.push(env.DB.prepare(`
                        INSERT INTO sale_items (id, sale_id, item_id, quantity, unit_price, gst_percentage, amount, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    `).bind(lineId, id, ...values));
                }
            }
        }

        try {
            const results = await env.DB.batch(statements);
            if (!results[0]?.meta?.changes) return errorResponse(`${type === 'purchase' ? 'Purchase order' : 'Sale'} not found.`, 404);
        } catch (error) {
            return this.writeError(error, type);
        }

        return json(await this.getDocument(env, type, id));
    }

    private static async deleteDocument(env: InventoryEnv, type: DocumentType, id: string): Promise<Response> {
        const table = type === 'purchase' ? 'purchase_orders' : 'sales';
        const lineTable = type === 'purchase' ? 'purchase_items' : 'sale_items';
        const foreignKey = type === 'purchase' ? 'purchase_order_id' : 'sale_id';
        try {
            const results = await env.DB.batch([
                env.DB.prepare(`DELETE FROM ${lineTable} WHERE ${foreignKey} = ?`).bind(id),
                env.DB.prepare(`DELETE FROM ${table} WHERE id = ?`).bind(id),
            ]);
            return results[1]?.meta?.changes
                ? json({ success: true, id })
                : errorResponse(`${type === 'purchase' ? 'Purchase order' : 'Sale'} not found.`, 404);
        } catch (error) {
            return this.writeError(error, type);
        }
    }

    private static writeError(error: unknown, type: DocumentType): Response {
        const message = error instanceof Error ? error.message : String(error);
        if (/UNIQUE constraint failed/i.test(message)) return errorResponse('A document with this bill number already exists.', 409);
        if (/Insufficient stock|current_stock >= 0/i.test(message)) {
            return errorResponse(type === 'sale' ? 'The requested quantity exceeds available stock.' : 'This purchase cannot be reduced or deleted because some units have already been sold.', 409);
        }
        if (/FOREIGN KEY constraint failed/i.test(message)) return errorResponse('The selected item does not exist.', 400);
        if (/CHECK constraint failed/i.test(message)) return errorResponse('One or more values violate inventory constraints.', 400);
        console.error('Inventory write failed:', error);
        return errorResponse('Unable to save the inventory document.', 500);
    }
}
